Steps to insert mock data in UniVerseDB:
- Copy all the extracted files to /usr/uv/BP
- Run UniVerse
- Type 'RUNPY BP MOCKDATA.py' (Assuming you have already made PO.ITEM.MST , PO.VENDOR.MST , PO.ORDER.MST and PO.INVOICE.MST)

