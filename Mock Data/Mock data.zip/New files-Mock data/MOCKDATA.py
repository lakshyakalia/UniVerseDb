import u2py
import csv
import os
import random

path_base = '/usr/uv/BP/'

if os.name == 'posix':
	__clear_command = 'clear'
else:
	__clear_command = 'cls'

def __clear_screen():
	os.system(__clear_command)

def __random_item():
	id = str(random.randrange(0,9999))
	return '{:<05}'.format(id)

def __random_items():
	count = random.randrange(5,20)
	items = []
	for x in range(0,count):
		items.append(__random_item())
	return items

for i in range(4):
	if i == 0:
		dict_file_name = "PO.ITEM.MST"
		path = path_base + 'ITEM_DATA.csv'
	if i == 1:
		dict_file_name = "PO.ORDER.MST"
		path = path_base + 'ORDER_DATA.csv'
	if i == 2:
		dict_file_name = "PO.VENDOR.MST"
		path = path_base + 'VENDOR_DATA.csv'
	if i == 3:
		dict_file_name = "PO.INVOICE.MST"
		path = path_base + 'INVOICE_DATA.csv'

	u2py.Command('DELETE FROM ' + dict_file_name + ';').run()
	__clear_screen()
	print('Item records from ' + dict_file_name + ' have been purged...')
	dataFile=u2py.File(dict_file_name)
	print(path)
	with open(path) as csv_file:
		csv_reader = csv.reader(csv_file, delimiter=',')
		line_count = 0
		for row in csv_reader:
			str_line_count = str(line_count)
			if i == 0:
				rec_key = ""
				rec_key = '{:<05}'.format(str_line_count)
				data = [row[1], row[1], row[1]]
				dataFile.write(rec_key,u2py.DynArray(data))
				line_count += 1
			if i == 1:	
				data_array = u2py.DynArray()
				rec_key = ""
				address = ""
				rec_key = row[0]
				item_ids = ""
				item_cnts = 0
				item_amts = 0	
				data_array.insert(1, 0, 0, row[1])
				data_array.insert(2, 0, 0, row[2])
				data_array.insert(3, 0, 0, row[3])
				data_array.insert(4, 0, 0, row[4])
				data_array.insert(5, 0, 0, row[5])
				data_array.insert(6, 0, 0, row[6])
				data_array.insert(7, 0, 0, row[7])
				data_array.insert(8, 0, 0, row[8])
				address = bytes(row[9],'utf-8')+u2py.VM+bytes(row[10],'utf-8')+u2py.VM+bytes(row[11],'utf-8')+u2py.VM+bytes(row[12],'utf-8')
				data_array.insert(9, 0, 0, address)
				data_array.insert(10, 0, 0, row[13])
				item_ids  = bytes(row[14],'utf-8')+u2py.VM+bytes(row[15],'utf-8')+u2py.VM+bytes(row[16],'utf-8')+u2py.VM+bytes(row[17],'utf-8')
				item_cnts = bytes(row[18],'utf-8')+u2py.VM+bytes(row[19],'utf-8')+u2py.VM+bytes(row[20],'utf-8')+u2py.VM+bytes(row[21],'utf-8')
				item_amts = bytes(row[22],'utf-8')+u2py.VM+bytes(row[23],'utf-8')+u2py.VM+bytes(row[24],'utf-8')+u2py.VM+bytes(row[25],'utf-8')
				data_array.insert(11, 0, 0, item_ids)
				data_array.insert(12, 0, 0, item_cnts)
				data_array.insert(13, 0, 0, item_amts)
				data_array.insert(14, 0, 0, row[26])
				dataFile.write(rec_key,data_array)
				line_count += 1
			if i == 2:	
				data_array = u2py.DynArray()
				rec_key = ""
				address = ""
				rec_key = row[0]
				item_ids = ""
				data_array.insert(1, 0, 0, row[1])
				data_array.insert(2, 0, 0, row[2])
				address = bytes(row[3],'utf-8')+u2py.VM+bytes(row[4],'utf-8')+u2py.VM+bytes(row[5],'utf-8')+u2py.VM+bytes(row[6],'utf-8')
				data_array.insert(3, 0, 0, address)
				data_array.insert(4, 0, 0, row[7])
				item_ids = bytes(row[8],'utf-8')+u2py.VM+bytes(row[9],'utf-8')+u2py.VM+bytes(row[10],'utf-8')+u2py.VM+bytes(row[11],'utf-8')
				data_array.insert(5, 0, 0, item_ids)
				dataFile.write(rec_key,data_array)
			if i == 3:
				data_array = u2py.DynArray()
				rec_key = ""
				address = ""
				rec_key = row[0]
				item_ids = ""
				data_array.insert(1, 0, 0, row[1])
				item_ids = bytes(row[2],'utf-8')+u2py.VM+bytes(row[3],'utf-8')+u2py.VM+bytes(row[4],'utf-8')+u2py.VM+bytes(row[5],'utf-8')
				data_array.insert(2, 0, 0, item_ids)
				item_quantity = bytes(row[6],'utf-8')+u2py.VM+bytes(row[7],'utf-8')+u2py.VM+bytes(row[8],'utf-8')+u2py.VM+bytes(row[9],'utf-8')
				data_array.insert(3, 0, 0, item_quantity)
				data_array.insert(4, 0, 0, row[10])
				item_received = bytes(row[14],'utf-8')+u2py.VM+bytes(row[15],'utf-8')+u2py.VM+bytes(row[16],'utf-8')+u2py.VM+bytes(row[17],'utf-8')
				data_array.insert(5, 0, 0, item_received)
				data_array.insert(6, 0, 0, row[18])
				data_array.insert(7, 0, 0, row[19])
				data_array.insert(8, 0, 0, row[20])
				quantity_pending = bytes(row[21],'utf-8')+u2py.VM+bytes(row[22],'utf-8')+u2py.VM+bytes(row[23],'utf-8')+u2py.VM+bytes(row[24],'utf-8')
				data_array.insert(9, 0, 0, quantity_pending)
				dataFile.write(rec_key,data_array)
	print(f'Processed {line_count} lines.')
